# High performance in-memory data grid with Apache Ignite

All code samples, scripts and more in-depth examples for the book **High performance in-memory computing with Apache Ignite**.

[![alt text](/highperfomance-mini.jpg "book cover")](http://leanpub.com/ignite)
