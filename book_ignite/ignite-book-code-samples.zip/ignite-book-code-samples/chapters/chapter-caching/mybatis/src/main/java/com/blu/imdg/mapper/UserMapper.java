package com.blu.imdg.mapper;

import com.blu.imdg.dto.Employee;

/**
 * Created by shamim on 15/02/16.
 */
public interface UserMapper {

    Employee getEmploee (String ename);
}
