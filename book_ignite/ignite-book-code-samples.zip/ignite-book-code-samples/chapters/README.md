## Prerequisites
| N | Name    | Value                                                                                |
|---|---------|--------------------------------------------------------------------------------------|
| 1 | JDK     | Oracle JDK 8 and above                                                               |
| 2 | OS      | Linux, MacOS (10.6 and above), Windows XP and above, Windows Server (2008 and above) |
|3  | Ignite version| 1.6 or above |

> To compile, run the following command:

> mvn clean install
