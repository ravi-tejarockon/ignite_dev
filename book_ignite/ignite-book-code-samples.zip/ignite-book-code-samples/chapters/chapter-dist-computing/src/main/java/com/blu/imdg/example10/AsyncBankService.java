package com.blu.imdg.example10;

/**
 * Created by mikl on 26.10.16.
 */
public interface AsyncBankService {
    String NAME = "BANK_SERVICE";
}
