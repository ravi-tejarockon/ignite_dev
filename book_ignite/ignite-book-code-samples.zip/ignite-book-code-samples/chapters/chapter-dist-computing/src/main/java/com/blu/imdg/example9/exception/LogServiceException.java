package com.blu.imdg.example9.exception;

/**
 * Created by mikl on 30.10.16.
 */
public class LogServiceException extends Exception {
    public LogServiceException(Throwable cause) {
        super(cause);
    }
}
