package com.blu.imdg.common.bankData.model;

/**
 * Created by mikl on 24.10.16.
 */
public interface AccountCacheData {
}
