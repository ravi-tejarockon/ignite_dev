package com.blu.imdg.example7;

import com.blu.imdg.example3.ValidateMessage;

/**
 * Created by mikl on 07.08.16.
 */
public interface XsdValidatingService {
    boolean isOk(ValidateMessage msg);
}
