package com.blu.imdg.common;

/**
 * Created by mikl on 23.08.16.
 */
public class CommonConstants {
    public static final String CLIENT_CONFIG = "org/book/examples/simple-client-config.xml";
}
