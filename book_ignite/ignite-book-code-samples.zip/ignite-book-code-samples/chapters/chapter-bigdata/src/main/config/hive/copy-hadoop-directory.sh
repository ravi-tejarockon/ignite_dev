#!/usr/bin/env bash
cd $HADOOP_HOME/etc
mkdir hadoop-hive
cp ./hadoop/*.* ./hadoop-hive