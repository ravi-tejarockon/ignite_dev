#!/usr/bin/env bash
schematool -initSchema -dbType derby