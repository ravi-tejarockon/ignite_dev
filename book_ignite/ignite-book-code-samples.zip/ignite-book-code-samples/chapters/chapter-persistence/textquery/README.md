*Ignite Java8 TextQuery TextFields*

Build module with maven
    mvn clean install

To run this standalone application execute following command in current directory folder:
java -jar ./target/textquery-runnable.jar


***Description***

An example of searching objects in Ignite cache by text on the fields which were annotated as @QueryTextField

  The resource file @USA_NY_email_addresses.csv has been taken from open resource in the internet
   http://emailaddresseslists.com/downloads-email/download-usa-new-york-ny-email-database-mailing-list-addresses-ids-part-047-of-100-909152707/
