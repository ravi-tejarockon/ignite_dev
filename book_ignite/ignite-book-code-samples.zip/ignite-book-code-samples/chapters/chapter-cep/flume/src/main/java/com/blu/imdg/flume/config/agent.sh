./flume-ng agent --conf conf --conf-file /home/user/apache-flume-1.6.0-bin/conf/single-node-demo.properties --name a1 -Dflume.root.logger=INFO,console
#Hadoop and hive in classpath
# add asm-all-4.2 lib
#netcat
nc host port

#for ignite example
./flume-ng agent --conf conf --conf-file /home/user/apache-flume-1.6.0-bin/conf/single-node-demo.properties --name a1