package com.blu.imdg.dto;

/**
 * Created by shamim on 05/08/16.
 */
public enum Level {
    GREEN,
    YELLOW,
    RED
}
